var config = {
	apiKey: "AIzaSyAE5HbseiPbPcl9Z8QCYX2ub4vJqSmhOcs"
	, authDomain: "webapp-1df4d.firebaseapp.com"
	, databaseURL: "https://webapp-1df4d.firebaseio.com"
	, storageBucket: "webapp-1df4d.appspot.com"
	, messagingSenderId: "99620978271"
};
firebase.initializeApp(config);
jQuery(document).ready(function () {
	$('#login-box').hide();
	$('#bigblock').hide();
	$('#navbar').hide();
});

function populateTable() {
	for (var i = 0; i < 5; i++) {
		var scoresRef = firebase.database().ref(i);
		scoresRef.on("value", function (data) {
			jQuery('#comptable').append('<div class="row"><div class="mdl-grid mdl-grid--no-spacing"><div class="bgcol mdl-cell mdl-cell--12-col">' + data.val().Date + '</div></div><div class="mdl-grid mdl-grid--no-spacing"><div class="bgcol mdl-cell mdl-cell--4-col mdl-cell--1-col-phone">' + data.val().HomeTeam + '</div><div class="bgcol mdl-cell mdl-cell--4-col mdl-cell--2-col-phone"><input type="number" class="mdl-textfield__input scoreenter"><p class="xmid">X</p><input type="number" class="mdl-textfield__input scoreenter"></div><div class="bgcol mdl-cell mdl-cell--4-col mdl-cell--1-col-phone">' + data.val().AwayTeam + '</div></div></div>');
		});
	}
}

function toggleSignIn() {
	if (firebase.auth().currentUser) {
		// [START signout]
		firebase.auth().signOut();
		jQuery('#bigblock').hide();
		jQuery('#navbar').hide();
		jQuery('#login-box').show();
		// [END signout]
	}
	else {
		var email = document.getElementById('email').value;
		var password = document.getElementById('password').value;
		if (email.length < 4) {
			alert('Please enter an email address.');
			return;
		}
		if (password.length < 4) {
			alert('Please enter a password.');
			return;
		}
		// Sign in with email and pass.
		// [START authwithemail]
		firebase.auth().signInWithEmailAndPassword(email, password).catch(function (error) {
			// Handle Errors here.
			var errorCode = error.code;
			var errorMessage = error.message;
			// [START_EXCLUDE]
			if (errorCode === 'auth/wrong-password') {
				alert('Wrong password.');
			}
			else {
				alert(errorMessage);
			}
			console.log(error);
			document.getElementById('quickstart-sign-in').disabled = false;
			// [END_EXCLUDE]
		});
		// [END authwithemail]
	}
	document.getElementById('quickstart-sign-in').disabled = true;
}
/**
 * Handles the sign up button press.
 */
function handleSignUp() {
	var email = document.getElementById('email').value;
	var password = document.getElementById('password').value;
	if (email.length < 4) {
		alert('Please enter an email address.');
		return;
	}
	if (password.length < 4) {
		alert('Please enter a password.');
		return;
	}
	// Sign in with email and pass.
	// [START createwithemail]
	firebase.auth().createUserWithEmailAndPassword(email, password).catch(function (error) {
		// Handle Errors here.
		var errorCode = error.code;
		var errorMessage = error.message;
		// [START_EXCLUDE]
		if (errorCode == 'auth/weak-password') {
			alert('The password is too weak.');
		}
		else {
			alert(errorMessage);
		}
		console.log(error);
		// [END_EXCLUDE]
	});
	// [END createwithemail]
}
/**
 * initApp handles setting up UI event listeners and registering Firebase auth listeners:
 *  - firebase.auth().onAuthStateChanged: This listener is called when the user is signed in or
 *    out, and that is where we update the UI.
 */
function guest() {
	jQuery('#login-box').hide();
	jQuery('#navbar').show();
	jQuery('#bigblock').show();
}

function initApp() {
	// Listening for auth state changes.
	// [START authstatelistener]
	firebase.auth().onAuthStateChanged(function (user) {
		// [END_EXCLUDE]
		if (user) {
			// User is signed in.
			jQuery('#login-box').hide();
			jQuery('#navbar').show();
			jQuery('#bigblock').show();
			populateTable()
			var displayName = user.displayName;
			var email = user.email;
			var emailVerified = user.emailVerified;
			var photoURL = user.photoURL;
			var isAnonymous = user.isAnonymous;
			var uid = user.uid;
			var providerData = user.providerData;
			// [START_EXCLUDE silent]
			document.getElementById('quickstart-sign-in-status').textContent = 'Signed in as:';
			document.getElementById('quickstart-sign-in-2').textContent = 'Sign out';
			console.log("This user has logged in before, lets show the code");
			// [END_EXCLUDE]
		}
		else {
			// User is signed out.
			// [START_EXCLUDE silent]
			jQuery('#navbar').hide();
			jQuery('#bigblock').hide();
			jQuery('#login-box').show();
			document.getElementById('quickstart-sign-in-status').textContent = 'Signed out';
			document.getElementById('quickstart-sign-in').textContent = 'Sign in';
			// [END_EXCLUDE]
		}
		// [START_EXCLUDE silent]
		document.getElementById('quickstart-sign-in').disabled = false;
		document.getElementById('quickstart-sign-in-2').disabled = false;
		// [END_EXCLUDE]
	});
	// [END authstatelistener]
	document.getElementById('quickstart-sign-in').addEventListener('click', toggleSignIn, false);
	document.getElementById('quickstart-sign-in-2').addEventListener('click', toggleSignIn, false);
	document.getElementById('quickstart-sign-up').addEventListener('click', handleSignUp, false);
}
window.onload = function () {
	initApp();
};
//
//The App Code Begins here
//
$(function () {
	var feed = new Firebase('https://webapp-1df4d.firebaseio.com/posts/');
	var index = 0;
	$('.loadNewsfeed').append("<div id='loading_spin'><center><i class='fa fa-5x fa-spinner fa-spin'> </i></center></div>");
	feed.on('child_added', function (snapshot) {
		var data = snapshot.val();
		var card = '<div class="card">' + '<div class="header">' + '<div class="user-panel">' + '<div class="pull-left">' + '<div class="user-img pull-left" style="background-image: url(\'https://pbs.twimg.com/profile_images/793471492004597760/8eB2dz2u.jpg\')"></div>' + '<div class="user-info pull-left">' + 'Nathan Bogale' + '<Br/>' + '<small>11/28/16 10:55PM</small>' + '</div>' + '</div>' + '<div class="pull-right feed-menu">' + '<i class="fa fa-ellipsis-v"></i>' + '</div>' + '<div class="clearfix"></div>' + '</div>' + '</div>' + '<div class="body">' + '	<div class="text">' + data.desc + '</div>';
		if (data.img != "") {
			card += '<div class="img">' + '<img src="' + data.img + '" />' + '</div>';
		}
		card += '</div></div>';
		$('#loading_spin').hide("fast");
		$('.loadNewsfeed').prepend(card);
	});
	$('.menu-bar').click(function () {
		$('.main-menu').toggleClass('active');
		$('.content-wrap').toggleClass('active');
		$(this).toggleClass('fa-bars fa-close')
	});
	$('.tab-item-btn').click(function () {
		var t = $(this).attr('tab-trigger');
		var i = $(this).index();
		$('.tab-item').removeClass('active');
		$('.tab-item:eq(' + i + ')').toggleClass('active');
		$('.tab-item-btn').removeClass('active');
		$(this).addClass('active');
		$('.menu-back').trigger('click');
	});
	$('input[name="postImg"]').on('change', function () {
		readURL(this, '.camera-preview', 'textarea[name="postImg64"]');
		$('textarea[name="postText"]').attr('placeholder', "Say something about this photo.")
	});
	$('.camera').click(function () {
		$('input[name="postImg"]').trigger("click");
	});
	$('#savePost').click(function () {
		var t = $('textarea[name="postText"]').val()
			, m = $('textarea[name="postImg64"]').val()
			, u = $('textarea[name="postDisc"]').val();
		feed.push({
			userid: u
			, desc: t
			, img: m
			, date: new Date()
		});
		$('textarea[name="postText"]').val('');
		$('textarea[name="postImg64"]').val('');
		$('textarea[name="postDisc"]').val('')
		$('.camera-preview').html("");
	});
	$('.chat-item').click(function () {
		$(this).addClass('active');
		$('.chat-content-holder').addClass('active');
		$('.general-top-menu').fadeOut("fast");
		$('.chat-top-menu').fadeIn("fast");
	});
	$('.menu-back').click(function () {
		$('.chat-item').removeClass('active');
		$('.chat-content-holder').removeClass('active');
		$('.general-top-menu').fadeIn("fast");
		$('.chat-top-menu').fadeOut("fast");
	});

	function readURL(input, elem, passTo) {
		$(elem).html("");
		if (input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function (e) {
				$(elem).append("<br/><img src='" + e.target.result + "' />");
				$(passTo).val(e.target.result);
				//$(elem).attr('src', e.target.result);
			}
			reader.readAsDataURL(input.files[0]);
		}
	}
});